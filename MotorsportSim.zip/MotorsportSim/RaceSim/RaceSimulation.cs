﻿using MotorsportSim.QuickRace;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorsportSim.RaceSim
{
    public class RaceSimulation
    {
        private Track track;
        private List<Car> cars;
        private int carCount;
        private int lapCount;
        private float raceTime = 0;
        private double waterLevel = 0.0;

        public RaceSimulation(Track track, List<Car> cars, RaceConfig raceConfig)
        {
            this.track = track;
            this.cars = cars;
            carCount = raceConfig.CarCount;
            lapCount = raceConfig.Laps;
        }

        public Track Track
        {
            set { track = value; }
        }

        public List<Vector> Waypoints
        {
            get { return track.Waypoints; }
        }

        public List<Car> Cars
        {
            get { return cars; }
            set { cars = value; }
        }

        public int CarCount
        {
            get { return carCount; }
        }

        public int LapCount
        {
            get { return lapCount; }
            set { lapCount = value; }
        }

        public float RaceTime
        {
            get { return raceTime; }
        }

        public void Update(float deltaT)
        {
            raceTime += deltaT;

            foreach (Car car in cars)
            {
                car.Update(raceTime, deltaT);
            }
        }

        public List<Car> SortCarsOrder()
        {
            return cars
                .OrderByDescending(car => car.RaceProgress())
                .ToList();
        }
    }
}