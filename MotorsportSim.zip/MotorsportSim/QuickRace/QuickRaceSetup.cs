﻿using MotorsportSim.General;
using MotorsportSim.RaceSim;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MotorsportSim.QuickRace
{
    public partial class QuickRaceSetup : Form
    {
        public QuickRaceSetup()
        {
            InitializeComponent();
            MenuUI.Form(this);
            MenuUI.ComboBox(Cbx_lapCount);
            MenuUI.BodyButton(Btn_startRace);
        }

        private void QuickRaceSetup_Load(object sender, System.EventArgs e)
        {
            //Set up combo boxes:
            Cbx_lapCount.Items.Clear();
            string[] lapOptions = { "3", "5", "10" };
            foreach (string laps in lapOptions)
            {
                Cbx_lapCount.Items.Add(laps);
            }
            Cbx_lapCount.SelectedIndex = 0;

            Cbx_teamCount.Items.Clear();
            string[] countOptions = { "4", "6", "8" };
            foreach (string count in countOptions)
            {
                Cbx_teamCount.Items.Add(count);
            }
            Cbx_teamCount.SelectedIndex = 0;

            Cbx_teamIndex.Items.Clear();
            string[] teamOptions = { "McLaren", "Mercedes", "Red Bull", "Ferrari" }; //Will later be read in from text file, then database
            foreach (string team in teamOptions)
            {
                Cbx_teamIndex.Items.Add(team);
            }
            Cbx_teamIndex.SelectedIndex = 0;
        }

        private void Btn_startRace_Click(object sender, System.EventArgs e)
        {
            //Might not need this section if using default selections
            if (Cbx_lapCount.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a valid number of laps.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Get selected values:
            string selectedLaps = Cbx_lapCount.SelectedItem.ToString();
            if (!int.TryParse(selectedLaps, out int laps))
            {
                MessageBox.Show("Please select a valid number of laps.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedTeamCount = Cbx_teamCount.SelectedItem.ToString();
            if (!int.TryParse(selectedTeamCount, out int teamCount))
            {
                MessageBox.Show("Please select a valid number of teams.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int teamIndex = Cbx_teamIndex.SelectedIndex; //Assuming index corresponds to team

            //Load the track waypoints in:
            Track track = new Track();
            track.LoadWaypointsFromFile("Tracks/Monaco.txt"); //Change to load different tracks later

            //Load teams and drivers:
            ITeamLoader teamLoader = new TextFileTeamLoader("Teams.txt");
            List<Team> teams = teamLoader.LoadTeams();

            RaceConfig config = new RaceConfig(track, laps, teamCount, teams);

            Race race = new Race(config);
            this.Close();
            race.ShowDialog();
            //raceStrategy.ShowDialog();
        }
    }
}